public interface MsgHandler {
    public void handleMsg(Msg m);
}
