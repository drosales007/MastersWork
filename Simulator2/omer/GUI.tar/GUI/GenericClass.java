import java.io.File;
import java.util.*;
import java.lang.reflect.*;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

class GenericClass extends Process {
    public static Object generic;
    static String className = "";
    static int ins = 0;
    static String last = "";
    public String toString()
    {	
    	System.out.println("GENERIC CLASS PRINT !!");
    	String now = "" + generic;
    	StringTokenizer st1 = new StringTokenizer(now," ");
    	StringTokenizer st2 = new StringTokenizer(last," ");
    	String result = "";    	
    	if (st1.countTokens() != st2.countTokens())
    	{
    		System.out.println("Tokens do not match. Aborting smart look!");
    		while(st1.hasMoreTokens())
        	{
        		String s1 = st1.nextToken();
        		result += s1 + "\n";
        	}
    		last = now;
    		return result;
    	}
    	while(st1.hasMoreTokens())
    	{
    		String s1 = st1.nextToken();
    		String s2 = st2.nextToken();
    		if (s1.equals(s2))
    			result += s1 + "\n";
    		else
    			result += "[" +s2+"->" + s1 +"]\n";
    	}
		last = now;
    	return result;
    }
    public GenericClass(Linker _linker) {
    	super(_linker);
    	ins++;
    	try 
		{
    		if (className == "")
    		{       	
	    		JFileChooser fileDialog;
	        	fileDialog = new JFileChooser();
	            fileDialog.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
	            int returnVal = fileDialog.showOpenDialog(null);
	            
	            if (returnVal == JFileChooser.APPROVE_OPTION) {
	                File file = fileDialog.getSelectedFile();
	                className= file.getName();
	                className= className.substring(0, className.length()-6);
	                System.out.println("The class to be loaded is " + className);
	            }
    		}
	    		
    		Class cls = Class.forName(className);
    		Constructor ctors[] = cls.getConstructors();
    		Object[] options = new String[ctors.length];
    		for (int i = 0; i < ctors.length; i++)
	    	{
    			String temp = "" + ctors[i];
    			if (temp.contains("public"))
    				temp=temp.substring(7);
	    		System.out.println(temp);
	    		options[i] = temp;
	    	}
			int selectedValue = JOptionPane.showOptionDialog(null, "Select Constructor", "Instance #" + ins,
					JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE,
    		        null, options, options[0]);
			Constructor ctor = ctors[selectedValue];
			Type types[] = ctor.getGenericParameterTypes();
			Object arglist[] = new Object[types.length];
    		for (int i = 0; i < types.length; i++)
    		{
    			String input = JOptionPane.showInputDialog("Instance # " + ins + " Argument #" +(i+1)+" [" +  types[i] + "]? ");
    			arglist[i] = Util.getObj(types[i],input);
    		}
            Util.println("Creating Instances");            
            generic = ctor.newInstance(arglist);
        }
        catch (Throwable e) {
        	System.err.println("1: " + e);
        }
    //new class constructor
    }
    public synchronized void handleMsg(Msg m) {
    	
    }
    public Object getGenericObject(){
    	return generic;
    }
}

