/**
 * @author omer
 *
 */
public class ProcessThread extends Thread 
{
	public Process p;
	ProcessMsgThread[] msgthreads;	
	public ProcessThread(String str, Process _p) 
    {
        super(str);
        p=_p;
        int N = p.getN();
        msgthreads = new ProcessMsgThread[N];
        for (int i = 0; i < N; i++)
        {
        	msgthreads[i]= new ProcessMsgThread(str,p, i);
        	msgthreads[i].start();
        }   
    }
    public void addEvent(Event e)
    {
    	p.addEvent(e);
    }
    public void wakeUp()
    {
    	p.wakeUp();
    }
    public void run() 
    {
    }
}