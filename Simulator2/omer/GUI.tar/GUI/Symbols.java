public class Symbols {
    public static final int Infinity = -1;
    public static final int Default_Connectivity = 1;
    // internet related
    public static final String nameServer = "linux02.ece.utexas.edu";
    public static final int ServerPort = 7039;
    // time bounds on messages in ms
    public static final int roundTime = 5000;
    public static final boolean debugFlag = true;
    public static int coordinator =0;
    public static double DONE=9999999;
    public static int SAVE = 0;
    public static int LOAD = 1;
    public static int NOTH = 2;
    public static int DEAD = 0;
    
}
