class PetersonAlgorithm extends Process implements Lock {
    public static boolean wantCS[] = {false, false};
    public int turn = 1;
    public void requestCS1(int i) {
        int j = 1 - i;
        wantCS[i] = true;
        Util.println("" + myId + ": wantCS set to true! wantCS[0]=" +wantCS[0] + " wantCS[1]=" + wantCS[1]);
        turn = j;
        Util.println("" + myId + ": wantCS[j]=" + wantCS[j] + " turn=" + turn + " j=" + j);
        while (wantCS[j] && (turn == j)) 
        	myWait();
        Util.println("" + myId + ": Got CS!");
    }
    
    public void releaseCS1(int i) {
        wantCS[i] = false;
        Util.println("" + myId + ": Left CS!");
    }
    public PetersonAlgorithm(Linker _linker) {
    	super(_linker);
    }
    public void requestCS()
    {
    	Util.println("" + myId + ": Invoking requestCS1!");
    	requestCS1(myId);
    }
    public void releaseCS(){
    	Util.println("" + myId + ": Invoking releaseCS1!");
    	releaseCS1(myId);
    }
    public synchronized void handleMsg(Msg m) {
    	
    }
}

