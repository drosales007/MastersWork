/*
 * JFrame.java
 *
 * Created on June 17, 2003, 1:11 PM
 */

/**
 *
 * @author  Vinit
 */


import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.event.*;


public class ProcessTrace extends JComponent {
    //Gui gui;
 //   CommModule comm;
    int x,y;
    int yGap;
    int gapX  = 60;
    int maxY;
    int maxX;
    int lMargin =50;
    int tMargin =50;
    int rMargin =50;
    int gapText =20;
    //[] = new int [maxProc];
    int gapY ;
    int radius = 10;
    int eventsSize ;
    int maxEvents ;
    JScrollPane parent;
    
    //Hints for fast refresh 
    int lastSelectedNode = 0;
    public int nextMessage =0; // Next Message to be proceesed by fast update thread
    public boolean changeSelectedNode =false;
    public boolean drawNewMessages = false;
    public ProcessTrace (JScrollPane _parent) {
//        comm = _comm;
        //gui = comm.gui;
        parent =_parent;
        parent.setViewportView (this);
        gapX =40;
        lMargin =50;
        tMargin =50;
        rMargin =50;
        gapText =20;
        //[] = new int [maxProc];
        //gapY = (maxY)/gui.getNumProc();
        radius = 3;
        //int eventsSize = Events.size ();
        //int maxEvents = MyUtil.maxArray (numEvents, numEvents.length);
        x = 50;
        y =20;
        MListener ml = new MListener ();
        addMouseListener (ml);
        //setPreferredSize (new Dimension (2000, 400));
        setBackground(Color.white); 
        setOpaque (true);
        parent = _parent;
        //scrollPane = new ScrollPane ();
        //scrollPane.add(this);
    }
    
 
    
    
    public void refresh (){
        repaint ();
    }
    public void refresh(int i){
        changeSelectedNode = true;
    }
    class TraceMsg
	 {
    	public int SEND = 0;
    	public int RECV = 1;
    	public int type;
    	public double ts;
    	public Vector vc;
    	public int otherpcs;
    	public String tag;
    	public String msg;
    	TraceMsg(String temp)
		{
    		StringTokenizer st = new StringTokenizer(temp," ");
    		String s = st.nextToken();
    		if (s.equals("Send"))
    			type = SEND;
    		else 
    			type = RECV;
    		s = st.nextToken();
			s = s.substring(1,s.length()-1);
    		ts = Double.parseDouble(s);
    		vc = new Vector();
    		for (int lv = 0; lv < Util.getDashboard().N; lv++)
    		{
    			vc.add(new String(st.nextToken()));
    		}
    		s = st.nextToken();
    		s = s.substring(0,s.length()-1);
    		otherpcs = Integer.parseInt(s);
    		s = st.nextToken();
    		s = s.substring(1,s.length()-1);
    		tag = new String(s);
    		msg = new String(st.nextToken());
		}
    	public String toString()
    	{
    		return "TYPE: " + type + " TS: " + ts + " VC: " + vc + " Other Pcs: " + otherpcs + " TAG: " + tag + " MSG: " + msg;
    	}
	 }
    class MListener extends MouseInputAdapter{
        
        public void mouseClicked (MouseEvent e){
            //TODO
        	/*//OS
        	int xc= e.getX ();
            int yc =e.getY ();
            for(int i = 0; i<comm.num_nodes;i++){
                if(isInRange (tMargin + i * gapY , yc,3)){
                    lastSelectedNode = comm.getSelectedNode ();
                    comm.setSelectedNode (i);
                    //gui.left.updateDisplay ();
                    comm.refreshGui ();
                    //refresh(i);
                    return;
                }
            }
            */ //OS
        }
        
        boolean isInRange (int y1,int y2,int r){
            
            int ydiff= Math.abs (y1-y2);
            if( ydiff < r) return true;
            return false;
        }
        
    }
    
    public void paintComponent (Graphics g1)
    {
    	 //TODO
        //OS
        
        Graphics2D g = (Graphics2D) (g1);
       Rectangle display = parent.getViewport ().getViewRect ();
        //if(Events.isEmpty())return;
        // int maxProc = s.gui.getNumProc ();
        //paint background
          Color oldC = g.getColor();
            g.setColor(getBackground());
            g.fillRect(0, 0, getWidth(), getHeight());
            g.setColor(oldC);
        
        maxY= getHeight ()-tMargin;
        maxX= getWidth ()-lMargin - rMargin;
        int num_nodes = Util.getDashboard().N;
        gapY = (maxY)/num_nodes;
        //int eventsSize = Events.size ();
        //int totalEvents = comm.getLastMessageId ();
        //lastX =0;
        
        //g.drawRect (20,40,maxX,maxY);
        
         Stroke sOld ;
            BasicStroke stroke;
            sOld =g.getStroke ();
            float[] f = new float [5];
            f[0] =1;
            f[1] =f[2] =f[3]=f[4]= 0;
  
            for(int n = 0 ; n < num_nodes; ++n)
            {
	            //if(Util.getDashboard().mainWindow.nodeView.selectedNode == n){
	             
	            stroke = new BasicStroke (1,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND,1,f, 4);
	            g.setStroke (stroke);
	            g.drawLine (lMargin,tMargin + gapY *n ,maxX, tMargin + gapY *n);
	            g.setStroke (sOld);
	            g.drawString (String.valueOf (n), lMargin -20,tMargin + gapY*n);
            }
        //java.util.List msgQueue = comm.guiGetMessageQueue ();
         
		 Vector all = new Vector();
       for (int lv = 0; lv < num_nodes; lv++)
       {
       	Vector v = new Vector();
        
       	try
		{
            BufferedReader in = new BufferedReader(new FileReader("trace/Pcs "+lv+".txt"));
		 	String str = "a";
	        while (str!=null)
	        {
	        	str = in.readLine();
	        	if (str == null)
	        		break;
	        	v.add(new TraceMsg(str));
//	        	Util.println(str);
		    }
	        in.close();
		}catch (Exception e)
		{
			Util.println("Exception: " + e.toString());
					
		}
		all.add(v);		
       }
       
       //all should be a vector of vectors.. the first vector is the size of number of processes
       // the internal vector has every line as an entry
       for (int i = 0; i < all.size(); i++) //for every process, 
       {
       		Vector allMsgs = (Vector)all.get(i); //all msgs for this process
       		for (int j = 0; j < allMsgs.size(); j++) // for all msgs, find
       		{
       			TraceMsg thismsg = (TraceMsg)allMsgs.get(j);
       			if (thismsg.type == thismsg.SEND) // for every send msg
       			{
       				int receiver = thismsg.otherpcs; //go and look in the receiver, when it was received if at all
       				Vector allMsgs2 = (Vector)all.get(receiver); //all msgs for receiver
       				for (int k = 0; k < allMsgs2.size(); k++) //for all msgs, find
       				{
       					TraceMsg thismsg2 = (TraceMsg)allMsgs2.get(k);
       	       			if (thismsg2.type == thismsg.RECV && thismsg2.otherpcs==i) // for every recv msg from i
       	       			{
       	       				if (thismsg.msg.equals(thismsg2.msg) && thismsg.tag.equals(thismsg2.tag)) //its the same msg
       	       				{
       	       					//we finally have a match, draw it!!
       	       					drawArrow(g,display,sOld,oldC,(int)thismsg.ts, (int)thismsg2.ts, i, receiver, thismsg.tag);
       	       				}
       	       			}
       				}       				
       			}
       		}
       }
       
       // OS: this was vinits old code
//       for (int t1 = 0; t1 < all.size(); t1++)
//       {
//       		Vector temp = (Vector)all.get(t1);
//       		for (int t2 = 0; t2 < temp.size(); t2++)
//       		{
//       			Util.println("2D Vector ["+t1+","+t2+"]"+(TraceMsg)temp.get(t2));
//       			
//       		}
//       			
//       }
       //find first receive, if the corresponding send is the first one, then show it
        //nextMessage = msgQueue.size();
       
       
       // OS:  the following has some bug, it will not work in non-FIFO case anyway, so i am going to write a code to use absolute time to draw the trace
       /*
        class Pointer {
        	public int send;
        	public int recv;
        	Pointer()
			{
        		send = recv = 0;
			}
        }
        Vector pointers = new Vector();
        for (int i = 0; i < num_nodes; i++)
        {
        	pointers.add(new Pointer());
        }
      for (int t1 = 0; t1 < all.size(); t1++)
      {
      		Vector temp = (Vector)all.get(t1);
      		int start = ((Pointer)pointers.get(t1)).send; //initially i will start looking from 0
      		((Pointer)pointers.get(t1)).send= -1;
      		int t22;
      		for (t22 = start; t22 < temp.size(); t22++) //start looking for the first sent msg
      		{
      			if (((TraceMsg)temp.get(t22)).type == ((TraceMsg)temp.get(t22)).SEND)
				{
      				((Pointer)pointers.get(t1)).send = t22;
      				break;
				}
      		}
      		if (t22 == temp.size())
      			continue;
      		// t22 should have my first send for t1 process
      		int start2 = ((Pointer)pointers.get(t1)).recv; //where was my last receive, start from there
      		((Pointer)pointers.get(t1)).recv= -1;
      		for (int t2 = start2; t2 < temp.size(); t2++)
      		{
      			((Pointer)pointers.get(t1)).recv= -1;
      			if (((TraceMsg)temp.get(t2)).type == ((TraceMsg)temp.get(t2)).RECV)
				{
      				((Pointer)pointers.get(t1)).recv = t2;
      				break;
				}
      		}
      }
         while(true)
      {
      	  for (int t1 = 0; t1 < all.size(); t1++)
	      {
      	  Util.println("Checking pcs " + t1 );
	      	
      	  		Vector temp = (Vector)all.get(t1);
	      		int firstrecv = ((Pointer)pointers.get(t1)).recv;
	      Util.println("first recv " + firstrecv);
	  	      		if (firstrecv == -1)
	      			continue;
	      		TraceMsg tracemsg = (TraceMsg)temp.get(firstrecv);
	      Util.println("tracemsg " + tracemsg);
	  	  	  		int sender = tracemsg.otherpcs;
	      		Vector temp2 = (Vector)all.get(sender);
	      		int firstsendofmysender = ((Pointer)pointers.get(sender)).send;
	      	  		if (firstsendofmysender == -1)
	      			continue;
	      	  
	      		TraceMsg tracemsg2 = (TraceMsg)temp2.get(firstsendofmysender);
	      Util.println("tracemsg2 " + tracemsg2);
			  		int hisreceiver = tracemsg2.otherpcs;
	      		if (t1 == hisreceiver && tracemsg.tag.equals(tracemsg2.tag) && tracemsg.msg.equals(tracemsg2.msg)) //only works for fifo
	     		{
	      Util.println("matched!" + tracemsg);
	    			
	      			drawArrow(g,display,sOld,oldC,(int)tracemsg2.ts, (int)tracemsg.ts, sender, t1, tracemsg.tag);
	      		
	      			int start = ((Pointer)pointers.get(sender)).send +1;
	      			((Pointer)pointers.get(sender)).send= -1;
          			for (int t2 = start ; t2 < temp2.size(); t2++)
	          		{
          				Util.println("before");
	          			if (((TraceMsg)temp2.get(t2)).type == ((TraceMsg)temp2.get(t2)).SEND)
	    				{
	          				((Pointer)pointers.get(sender)).send = t2;
	          				break;
	    				}
	          			Util.println("after");
	          		}
          			int start2 = ((Pointer)pointers.get(t1)).recv +1;
          			((Pointer)pointers.get(t1)).recv= -1;
          			for (int t2 = start2; t2 < temp.size(); t2++)
	          		{
	          			if (((TraceMsg)temp.get(t2)).type == ((TraceMsg)temp.get(t2)).RECV)
	    				{
	          				((Pointer)pointers.get(t1)).recv = t2;
	          				break;
	    				}
	          		}
	      		}
	      }
	      int t11;
	      for (t11 = 0; t11 < all.size(); t11++)
	      {
	      	if (((Pointer)pointers.get(t11)).recv != -1)
	      		break;
	      }
	      if (t11 == all.size())
	      	break;
      }
      */
    }

        
       void drawArrow(Graphics2D g, Rectangle display, Stroke sOld, Color oldC, int send, int recv, int source, int dest, String tag)
       {
        int x1= lMargin + send* gapX;//+ (int)(Math.random ()*10) ;
        int x2= lMargin + recv* gapX;//+(int)(Math.random ()*(double)gapX/3) ;// x[de.srcId][srcEventId];
       
        
        int y1 = tMargin + source* gapY; 
        int y2 = tMargin + dest* gapY;
        if(x2 > getSize().width) {
            setPreferredSize (new Dimension(getSize ().width + 2000, getSize ().height));
            revalidate();
        }
    /*OS TODO      if(display.x+display.width < x1 ) break; 
         if(!display.contains (x1,y1) &&  !display.contains(x2,y2)) //{System.out.println(" ....Optimiztion seems to work  ");
             continue;
         //}
      */ //OS TODO finish  
        sOld =g.getStroke ();
//       float[] f = new float [4];
//       f[0]  =0;
//       f[1]=f[2] =f[3] =1;
       
        BasicStroke s = new BasicStroke ((float)1.3);// (1,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND,1,f, 3);
        g.setStroke (s);
        //System.out.println(" SendEventId = " + sm.sendEventId+ " :  Send LamportClock = " + sm.send_lc);
        //System.out.println(" RecvEventId = " + sm.recvEventId+ " :  Recv LamportClock = " + sm.recv_lc);
//        int x1= lMargin + sm.sendEventId*gapX;//+ (int)(Math.random ()*10) ;
//        int x2= lMargin + sm.recvEventId*gapX+(int)(Math.random ()*35) ;// x[de.srcId][srcEventId];
//        int y1 = tMargin + sm.sourceId * gapY;
//        int y2 = tMargin + sm.destId* gapY;
        
        //int tempgapY= ((y2-y1)/Math.abs (y2-y1) * (radius + 13)) ;
        
        oldC = g.getColor ();
        Color c = MyUtil.translateColorMessages (tag);//sm.msg.getTag());
        g.setColor (c);
        g.drawLine (x1,y1,x2 ,y2);
        g.fillPolygon (MyUtil.getArrow (x1,y1,x2,y2, 10,5, 0.5));
        g.fillOval (x1-radius,y1-radius,radius*2,radius*2);
        g.drawOval (x2-radius,y2-radius,radius*2,radius*2);
        g.setStroke (sOld);
        //g.drawString (de.srcState, x1-gapText ,y1 -tempgapY);
        //g.drawString (de.destState,x2-gapText ,y2 +tempgapY);
        
        g.drawString ( tag/*sm.msg.getTag ().substring (0,3)*/,(x1 + x2) /2 ,(y1 + y2) /2);
        //g.fillOval (x[de.srcId][de.srcEventId] - radius  ,y[de.srcId][de.srcEventId]-radius , 2*(radius ),2*(radius ));
        g.setStroke (sOld);
        g.setColor (oldC);
	
       }
}      
       /*
                for( int j = 0 ; j < numEvents[i]; j++){
                    //int x1 = lMargin +  j*gapX[i];
                    int y1 =tMargin +  i*gapY;
                    //g.drawOval(x1-radius,y1-radius,radius*2,radius*2);
                    x[i][j] =lMargin ;//x1;
                    y[i][j]= y1;
              
                }
              
              */
           
            
            
       // }
           /*
            for(int j= 0 ; j< eventsSize;j++){
            
                DisplayEvent de = (DisplayEvent) Events.get(j);
                int i= de.destEventId;
            
            
            
                if(x[de.srcId][de.srcEventId] > (x[de.destId][i] - gapX)  ){
            
                    x[de.destId][i] =x[de.srcId][de.srcEventId] + gapX;
                }
            
                x[de.srcId][de.srcEventId +1 ]= Util.max(x[de.srcId][de.srcEventId] + gapX,x[de.srcId][de.srcEventId +1]);
                //if( (de.destEventId < 199) && (x[de.destId][de.destEventId +1 ] - x[de.destId][de.destEventId] <gapX[de.destId] ) ){
                x[de.destId][i+1] = Util.max(x[de.destId][i] +gapX,x[de.destId][i+1]);
                if( x[de.destId][i+1] > lastX) lastX =x[de.destId][i+1] ;
            
                //}
            
            }
            */
//        for(int i =0;i<gui.getNumProc ();i++){
//            
//            for( int j = 0 ; j < numEvents[i]; j++){
//                int x1= x[i][j];
//                int y1 =y[i][j];
//                g.drawOval (x1-radius,y1-radius,radius*2,radius*2);
//                //g.drawString(String.valueOf(j),x1,y1);
//                
//            }
//        }
//        
//        for(int i= 0 ; i< Events.size ();i++){
//            
//            DisplayEvent de = (DisplayEvent) Events.get (i);
//            int destEventId = de.destEventId - currentEventNum[de.destId];
//            int srcEventId = de.srcEventId - currentEventNum[de.srcId];
//            
//            Stroke sOld ;
//            sOld =g.getStroke ();
//                /*float[] f = new float [4];
//                f[0]  =0;
//                f[1]=f[2] =f[3] =1;
//                 */BasicStroke s = new BasicStroke ((float)1.3);// (1,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND,1,f, 3);
//                 g.setStroke (s);
//                 int x1= x[de.srcId][srcEventId];
//                 int y1 =y[de.srcId][srcEventId];
//                 int x2 = x[de.destId][destEventId];
//                 int y2 = y[de.destId][destEventId];
//                 int tempgapY= ((y2-y1)/Math.abs (y2-y1) * (radius + 13)) ;
//                 
//                 Color oldC = g.getColor ();
//                 Color c = MyUtil.translateColorMessages (de.command);
//                 g.setColor (c);
//                 g.drawLine (x1,y1,x2 ,y2);
//                 g.fillPolygon (MyUtil.getArrow (x1,y1,x2,y2, 10,5, 0.5));
//                 g.setStroke (sOld);
//                 g.drawString (de.srcState, x1-gapText ,y1 -tempgapY);
//                 g.drawString (de.destState,x2-gapText ,y2 +tempgapY);
//                 
//                 g.drawString ( de.command.substring (0,3),(x[de.srcId][srcEventId] + x[de.destId][destEventId]) /2 ,(y[de.srcId][srcEventId] + y[de.destId][destEventId]) /2);
//                 //g.fillOval (x[de.srcId][de.srcEventId] - radius  ,y[de.srcId][de.srcEventId]-radius , 2*(radius ),2*(radius ));
//                 g.setStroke (sOld);
//                 g.setColor (oldC);
//        }
//        System.out.println ("Pending Events = " + pendingSends.size ());
//        for(int i=0;i<pendingSends.size ();i++){
//            
//            PendingEvent pe = (PendingEvent)pendingSends.get (i);
//            //int destEventId = pe.destEventId - currentEventNum[pe.destId];
//            int srcEventId = pe.srcEventId - currentEventNum[pe.srcId];
//            
//            Stroke sOld ;
//            sOld =g.getStroke ();
//            float[] f = new float [5];
//            f[0] =1;
//            f[1] =f[2] =f[3]=f[4]= 0;
//            Stroke stroke = new BasicStroke ((float)0.4,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND,1,f, 4);
//            g.setStroke (stroke);
//            int x1= x[pe.srcId][srcEventId];
//            int y1 =y[pe.srcId][0];
//            int x2 = Util.max (x[pe.destId][numEvents[pe.destId]],x1)+ gapX;
//            int y2 = y[pe.destId][0];
//            //int tempgapY= ((y2-y1)/Math.abs(y2-y1) * (radius + 13)) ;
//            
//            Color oldC = g.getColor ();
//            Color c = MyUtil.translateColorMessages (pe.command);
//            g.setColor (c);
//            g.drawLine (x1,y1,x2 ,y2);
//            g.fillPolygon (MyUtil.getArrow (x1,y1,x2,y2, 10,5, 0.5));
//            
//            //g.drawString(pe.srcState, x1-gapText ,y1 -tempgapY);
//            //g.drawString(pe.destState,x2-gapText ,y2 +tempgapY);
//            
//            g.drawString ( pe.command.substring (0,3),(x1+x2) /2 ,(y1+y2) /2);
//            //g.fillOval (x[de.srcId][de.srcEventId] - radius  ,y[de.srcId][de.srcEventId]-radius , 2*(radius ),2*(radius ));
//            g.setStroke (sOld);
//            g.setColor (oldC);
//            
//        }
//        
//        
//    }
    
    
//}


//    public int[] numEvents = new int[20];
//    int x[][] ;
//    int y[][] ;
//
//    // = new int [maxProc][200];
//    int currentEventNum[];
//    int maxProc ;
//    public java.util.Vector Events = new java.util.Vector () ;
//    public Vector pendingSends = new Vector ();
//    //int radius =6;
//    //Simulator s;

//    MyCanvas myCanvas;
//    int lastX=0;

//    public ProcessTrace (CommModule _comm) {
//        comm = _comm;
//        gui = comm.gui;
//        maxProc = gui.getNumProc ();
//        currentEventNum = new int[maxProc];
//        for(int i = 0;i <maxProc;i++){
//            currentEventNum[i] =0 ;
//        }
//        x = new int [gui.getNumProc ()][1000];
//        y = new int [gui.getNumProc ()][1000];
//        scrollPane = new ScrollPane ();
//
//        myCanvas = new MyCanvas ();
//        scrollPane.add (myCanvas);
//
//        this.add (scrollPane);
//        myCanvas.setSize (2000,(int)scrollPane.getSize ().getHeight () - 20);
//        myCanvas.setBackground (Color.white);
//        MListener ml = new MListener ();
//        myCanvas.addMouseListener (ml);
//
//        for(int i = 0; i < 20;numEvents [i]=0,  i++);
//
//
//        //this.s =s;
//        prepareDisplay ();
//        update();
//        //setSize (1000,750);
//
//    }
//
//    public void update (){
//        myCanvas.repaint ();
//        scrollPane.setScrollPosition ((lastX - scrollPane.getSize ().width/2) , 0) ;
//    }
//    public synchronized void addEvent (int type, int srcId, int destId, String command,String msg, String state ){
//        DisplayEvent de;
//        PendingEvent pe;
//
//        if(type == SimEvent.SEND){
//
//            pe = new PendingEvent (srcId,destId, command , msg,state);
//            pendingSends.add (pe);
//
//            numEvents[srcId]++;
//
//        }
//
//        if(type == SimEvent.BROADCAST){
//            for(int i =0 ;i<gui.getNumProc ();i++){
//                if(i != srcId){
//                    pe = new PendingEvent (srcId,i, command , msg,state);
//                    pendingSends.add (pe);
//
//                }
//            }
//            numEvents[srcId] ++ ;
//        }
//
//        if(type == SimEvent.RECEIVE){
//            Vector tempVector=new Vector ();
//            if( lastX >myCanvas.getSize ().width -40){
//                System.out.println ("Deleting old Events");
//                for(int i =0;i<Events.size ();i++){
//                    DisplayEvent tempde = (DisplayEvent)Events.get (i);
//                    if(x[tempde.srcId][tempde.srcEventId] < myCanvas.getSize ().width/3) {
//                        tempVector.add (tempde);
//                        //if(tempde.srcEventId > currentEventNum[tempde.srcId] -1)
//                        //  currentEventNum[tempde.srcId]= tempde.srcEventId +1;
//                        //if(tempde.destEventId > currentEventNum[tempde.destId] -1)
//                        //  currentEventNum[tempde.destId]= tempde.destEventId +1;
//                        //numEvents[tempde.srcId]--;
//                        //numEvents[tempde.destId]--;
//                        //    Events.remove(tempde);
//                    }
//                }
//                while(!tempVector.isEmpty ()){
//                    DisplayEvent debug =(DisplayEvent)tempVector.get (0);
//                    System.out.println ("Deleting Event SrcID ="+debug.srcId+" SEId ="+debug.srcEventId+" DestId="+debug.destId+"DestEventId="+debug.destEventId);
//                    Events.remove ((DisplayEvent)tempVector.remove (0)) ;
//
//                    if(debug.srcEventId > currentEventNum[debug.srcId] -1)
//                        currentEventNum[debug.srcId]= debug.srcEventId +1;
//                    if(debug.destEventId > currentEventNum[debug.destId] -1)
//                        currentEventNum[debug.destId]= debug.destEventId +1;
//                    //                Events.remove((DisplayEvent)tempVector.remove(0)) ;
//
//
//                }
//
//            }
//            for(int i = 0; i< pendingSends.size ();i++){
//                pe = new PendingEvent (srcId,destId, command , msg,state);
//                PendingEvent peOld = (PendingEvent) pendingSends.get (i);
//
//                if(pe.compare (peOld)){
//                    de = new DisplayEvent (srcId,destId,pe.srcEventId, command ,msg, peOld.srcState, pe.srcState);
//                    numEvents[destId]++;
//                    de.srcEventId = peOld.srcEventId;
//                    pendingSends.remove (peOld);
//                    Events.add (de);
//                    prepareDisplay ();
//                    update ();
//                    return;
//                }
//            }
//            System.out.println ("\n\n\n NO Corresponding SEND found **** \n\n\n ");
//        }
//        prepareDisplay ();
//        update ();
//    }
//
//
//    public  void prepareDisplay (){
//        // if(Events.isEmpty())return;
//
//
//
//        int maxY= myCanvas.getHeight ()-50;
//        int maxX= myCanvas.getWidth ()-80;
//        int lMargin =50;
//        int tMargin =50;
//        int rMargin =50;
//        int gapText =20;
//        int gapX  = 120;
//        int gapY = (maxY)/maxProc;
//        int radius = 10;
//        int eventsSize = Events.size ();
//        int maxEvents = MyUtil.maxArray (numEvents, numEvents.length);
//        lastX =0;
//
//        for(int i =0;i< gui.getNumProc ();i++){
//             y[i][0]= tMargin +  i*gapY;
//            for( int j = 0 ; j < numEvents[i]; j++){
//                //int x1 = lMargin +  j*gapX[i];
//                int y1 =tMargin +  i*gapY;
//                //g.drawOval(x1-radius,y1-radius,radius*2,radius*2);
//                x[i][j] =lMargin ;//x1;
//                y[i][j]= y1;
//
//            }
//               /*
//                Stroke sOld ;
//                BasicStroke stroke;
//                sOld =g.getStroke();
//                float[] f = new float [5];
//                f[0] =1;
//                f[1] =f[2] =f[3]=f[4]= 0;
//                Color oldC = null;
//                if(s.node[i].getNodeColor()> 0){
//                 oldC = g.getColor();
//                 Color c = Util.translateColor(s.node[i].getNodeColor());
//                 g.setColor(c);
//                }
//                 if(i== s.gui.getSelectedNode()){
//                   stroke = new BasicStroke((float)3,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND,1,f, 4);
//
//                }
//                else{
//                    stroke = new BasicStroke(1,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND,1,f, 4);
//                }
//                g.setStroke(stroke);
//                g.drawLine(lMargin,y[i][0],maxX, y[i][numEvents[i]-1]);
//                g.setStroke(sOld);
//                if(s.node[i].getNodeColor()> 0){
//
//                 g.setColor(oldC);
//                }
//                g.drawString(String.valueOf(i), lMargin -20,y[i][0]);
//                */
//
//        }
//
//        for(int j= 0 ; j< Events.size ();j++){
//
//            DisplayEvent de = (DisplayEvent) Events.get (j);
//            int destEventId = Util.max (de.destEventId - currentEventNum[de.destId],0);
//            int srcEventId = Util.max (de.srcEventId - currentEventNum[de.srcId],0);
//
//
//            System.out.println ("SrcEId = " +srcEventId+"de.srcId=" +de.srcId+" DestEId = "+destEventId+"de.DestId= "+ de.destId );
//            if(x[de.srcId][srcEventId] > (x[de.destId][destEventId] - gapX)  ){
//
//                x[de.destId][destEventId] = x[de.srcId][srcEventId] + gapX;
//            }
//
//            x[de.srcId][srcEventId +1 ]= Util.max (x[de.srcId][srcEventId] + gapX,x[de.srcId][srcEventId +1]);
//            //if( (de.destEventId < 199) && (x[de.destId][de.destEventId +1 ] - x[de.destId][de.destEventId] <gapX[de.destId] ) ){
//            x[de.destId][destEventId+1] = Util.max (x[de.destId][destEventId] +gapX,x[de.destId][destEventId+1]);
//            if( x[de.destId][destEventId+1] > lastX) lastX =x[de.destId][destEventId+1] ;
//
//            //}
//
//        }
//            /*
//            for(int i =0;i<s.gui.getNumProc();i++){
//
//                for( int j = 0 ; j < numEvents[i]; j++){
//                    int x1= x[i][j];
//                    int y1 =y[i][j];
//                    g.drawOval(x1-radius,y1-radius,radius*2,radius*2);
//                    //g.drawString(String.valueOf(j),x1,y1);
//
//                }
//            }
//             */
//
//
//
//
//    }
//
//
//
//    class MListener extends MouseInputAdapter{
//
//        public void mouseClicked (MouseEvent e){
//            int xc= e.getX ();
//            int yc =e.getY ();
//            for(int i = 0; i<gui.getNumProc ();i++){
//                if(isInRange (y[i][0],xc,yc,3)){
//                    gui.setSelectedNode (i);
//                    gui.left.updateDisplay ();
//                    myCanvas.repaint ();
//                    return;
//                }
//            }
//        }
//
//        boolean isInRange (int y1,int x2,int y2,int r){
//
//            int ydiff= Math.abs (y1-y2);
//            if( ydiff < r) return true;
//            return false;
//        }
//
//    }
//
//
//    class MyCanvas extends Canvas{
//
//
//        public void paint (Graphics g1){
//            //if(Events.isEmpty())return;
//           // int maxProc = s.gui.getNumProc ();
//
//            int maxY= myCanvas.getHeight ()-50;
//            int maxX= myCanvas.getWidth ()-80;
//            int lMargin =50;
//            int tMargin =50;
//            int rMargin =50;
//            int gapText =20;
//            int gapX  = 120; //[] = new int [maxProc];
//            int gapY = (maxY)/maxProc;
//            int radius = 10;
//            int eventsSize = Events.size ();
//            int maxEvents = MyUtil.maxArray (numEvents, numEvents.length);
//            lastX =0;
//            Graphics2D g = (Graphics2D) (g1);
//            //g.drawRect (20,40,maxX,maxY);
//
//            for(int i =0;i<maxProc;i++){
//             /*
//                for( int j = 0 ; j < numEvents[i]; j++){
//                    //int x1 = lMargin +  j*gapX[i];
//                    int y1 =tMargin +  i*gapY;
//                    //g.drawOval(x1-radius,y1-radius,radius*2,radius*2);
//                    x[i][j] =lMargin ;//x1;
//                    y[i][j]= y1;
//
//                }
//
//              */
//                Stroke sOld ;
//                BasicStroke stroke;
//                sOld =g.getStroke ();
//                float[] f = new float [5];
//                f[0] =1;
//                f[1] =f[2] =f[3]=f[4]= 0;
//                Color oldC = null;
//                if(comm.node[i].getNodeColor ()> 0){
//                    oldC = g.getColor ();
//                    Color c = MyUtil.translateColor (comm.node[i].getNodeColor ());
//                    g.setColor (c);
//                }
//                if(i== comm.gui.getSelectedNode ()){
//                    stroke = new BasicStroke ((float)3.5,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND,1,f, 4);
//
//                }
//                else{
//                    stroke = new BasicStroke (1,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND,1,f, 4);
//                }
//                g.setStroke (stroke);
//                g.drawLine (lMargin,y[i][0],maxX, y[i][0]);
//                g.setStroke (sOld);
//                if(comm.node[i].getNodeColor ()> 0){
//
//                    g.setColor (oldC);
//                }
//                g.drawString (String.valueOf (i), lMargin -20,y[i][0]);
//
//
//            }
//           /*
//            for(int j= 0 ; j< eventsSize;j++){
//
//                DisplayEvent de = (DisplayEvent) Events.get(j);
//                int i= de.destEventId;
//
//
//
//                if(x[de.srcId][de.srcEventId] > (x[de.destId][i] - gapX)  ){
//
//                    x[de.destId][i] =x[de.srcId][de.srcEventId] + gapX;
//                }
//
//                x[de.srcId][de.srcEventId +1 ]= Util.max(x[de.srcId][de.srcEventId] + gapX,x[de.srcId][de.srcEventId +1]);
//                //if( (de.destEventId < 199) && (x[de.destId][de.destEventId +1 ] - x[de.destId][de.destEventId] <gapX[de.destId] ) ){
//                x[de.destId][i+1] = Util.max(x[de.destId][i] +gapX,x[de.destId][i+1]);
//                if( x[de.destId][i+1] > lastX) lastX =x[de.destId][i+1] ;
//
//                //}
//
//            }
//            */
//            for(int i =0;i<gui.getNumProc ();i++){
//
//                for( int j = 0 ; j < numEvents[i]; j++){
//                    int x1= x[i][j];
//                    int y1 =y[i][j];
//                    g.drawOval (x1-radius,y1-radius,radius*2,radius*2);
//                    //g.drawString(String.valueOf(j),x1,y1);
//
//                }
//            }
//
//            for(int i= 0 ; i< Events.size ();i++){
//
//                DisplayEvent de = (DisplayEvent) Events.get (i);
//                int destEventId = de.destEventId - currentEventNum[de.destId];
//                int srcEventId = de.srcEventId - currentEventNum[de.srcId];
//
//                Stroke sOld ;
//                sOld =g.getStroke ();
//                /*float[] f = new float [4];
//                f[0]  =0;
//                f[1]=f[2] =f[3] =1;
//                 */BasicStroke s = new BasicStroke ((float)1.3);// (1,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND,1,f, 3);
//                 g.setStroke (s);
//                 int x1= x[de.srcId][srcEventId];
//                 int y1 =y[de.srcId][srcEventId];
//                 int x2 = x[de.destId][destEventId];
//                 int y2 = y[de.destId][destEventId];
//                 int tempgapY= ((y2-y1)/Math.abs (y2-y1) * (radius + 13)) ;
//
//                 Color oldC = g.getColor ();
//                 Color c = MyUtil.translateColorMessages (de.command);
//                 g.setColor (c);
//                 g.drawLine (x1,y1,x2 ,y2);
//                 g.fillPolygon (MyUtil.getArrow (x1,y1,x2,y2, 10,5, 0.5));
//                 g.setStroke (sOld);
//                 g.drawString (de.srcState, x1-gapText ,y1 -tempgapY);
//                 g.drawString (de.destState,x2-gapText ,y2 +tempgapY);
//
//                 g.drawString ( de.command.substring (0,3),(x[de.srcId][srcEventId] + x[de.destId][destEventId]) /2 ,(y[de.srcId][srcEventId] + y[de.destId][destEventId]) /2);
//                 //g.fillOval (x[de.srcId][de.srcEventId] - radius  ,y[de.srcId][de.srcEventId]-radius , 2*(radius ),2*(radius ));
//                 g.setStroke (sOld);
//                 g.setColor (oldC);
//            }
//            System.out.println ("Pending Events = " + pendingSends.size ());
//            for(int i=0;i<pendingSends.size ();i++){
//
//                PendingEvent pe = (PendingEvent)pendingSends.get (i);
//                //int destEventId = pe.destEventId - currentEventNum[pe.destId];
//                int srcEventId = pe.srcEventId - currentEventNum[pe.srcId];
//
//                Stroke sOld ;
//                sOld =g.getStroke ();
//                float[] f = new float [5];
//                f[0] =1;
//                f[1] =f[2] =f[3]=f[4]= 0;
//                Stroke stroke = new BasicStroke ((float)0.4,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND,1,f, 4);
//                g.setStroke (stroke);
//                int x1= x[pe.srcId][srcEventId];
//                int y1 =y[pe.srcId][0];
//                int x2 = Util.max (x[pe.destId][numEvents[pe.destId]],x1)+ gapX;
//                int y2 = y[pe.destId][0];
//                //int tempgapY= ((y2-y1)/Math.abs(y2-y1) * (radius + 13)) ;
//
//                Color oldC = g.getColor ();
//                Color c = MyUtil.translateColorMessages (pe.command);
//                g.setColor (c);
//                g.drawLine (x1,y1,x2 ,y2);
//                g.fillPolygon (MyUtil.getArrow (x1,y1,x2,y2, 10,5, 0.5));
//
//                //g.drawString(pe.srcState, x1-gapText ,y1 -tempgapY);
//                //g.drawString(pe.destState,x2-gapText ,y2 +tempgapY);
//
//                g.drawString ( pe.command.substring (0,3),(x1+x2) /2 ,(y1+y2) /2);
//                //g.fillOval (x[de.srcId][de.srcEventId] - radius  ,y[de.srcId][de.srcEventId]-radius , 2*(radius ),2*(radius ));
//                g.setStroke (sOld);
//                g.setColor (oldC);
//
//            }
//
//
//        }
//
//
//    }
//
//
//
//
//
//
//    class DisplayEvent{
//
//        int srcId;
//        int destId;
//        public int srcEventId;
//        int destEventId;
//        String command;
//        public String srcState;
//        String destState;
//        String msg;
//
//        public DisplayEvent ( int s, int d, int srcEventId, String command,String msg, String srcState, String destState){
//            srcId =s;
//            destId =d;
//            this.srcEventId = srcEventId ;//numEvents[srcId];
//            destEventId = numEvents[destId];
//            this.msg = msg;
//            this.command = command;
//            this.srcState = srcState;
//            this.destState = destState;
//        }
//
//    }
//
//
//    class PendingEvent{
//
//        int srcId;
//        int destId;
//        int srcEventId;
//        // int destEventId;
//        public String command;
//        public String srcState;
//        //String destState;
//        public String msg;
//        public PendingEvent ( int s, int d, String command,String msg, String state){
//            srcId =s;
//            destId =d;
//            srcEventId = numEvents[srcId];
//            //srcEventId = numEvents[srcId];
//            //destEventId = numEvents[destId];
//            this.msg =msg;
//            this.command = command;
//            this.srcState = state;
//        }
//
//        public  boolean compare (PendingEvent e2){
//            if(command.equals (e2.command) && msg.equals (e2.msg)&& destId == e2.destId && srcId == e2.srcId)
//                return true;
//            else return false;
//
//        }
//
//
//
//
//    }
//}
//	class SimEvent {
//	    
//	    static final int SEND  = 0;
//	    static final int BROADCAST =1;
//	    static final int RECEIVE = 2;
//	    
//	}
//
//
//
//
