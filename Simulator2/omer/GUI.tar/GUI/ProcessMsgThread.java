/**
 * @author omer
 *
 */
public class ProcessMsgThread extends Thread 
{
	public Process p;
	int src;
	public ProcessMsgThread(String str, Process _p, int _src) 
    {
        super(str);
        p=_p;
        src = _src;
    }
    public void run() 
    {
    	while(p.linker.connectivity[p.myId]!=Symbols.DEAD)
    	{
    		p.executeNextEvent(src);
	    }
    }
}