public class LamportMutex extends Process implements Lock {
    public DirectClock v;
    int[] q; // request queue
    public String Q;
    public LamportMutex(Linker _linker) {
    	super(_linker);
    	Util.println("["+myId+"] LM Constructor");
        v = new DirectClock(N, myId);
        q = new int[N];
        for (int j = 0; j < N; j++) 
            q[j] = Symbols.Infinity;
        Util.println("["+myId+"] q: "+MyUtil.getArrayString(q));     
    	Util.println("["+myId+"] v: "+v);
    	color = 0;
    	Q=MyUtil.getArrayString(q);
        
    }
    public synchronized void requestCS() {
    	Util.println("["+myId+"] LM ReqCS");
        v.tick();
        q[myId] = v.getValue(myId);
        Q=MyUtil.getArrayString(q);
        broadcastMsg("request", ""+q[myId]);
        while (!okayCS())
            myWait();
        Util.println("["+myId+"] I have CS");
        color = 1;
    }
    public synchronized void releaseCS() {
    	if (okayCS())
    	{	
	    	Util.println("["+myId+"] LM RelCS");        
	    	q[myId] = Symbols.Infinity;
	    	Q=MyUtil.getArrayString(q);
	        broadcastMsg("release", ""+v.getValue(myId));
    	}
    	else
    		Util.println("["+myId+"] LM RelCS but I aint got CS");
    	color = 0;
    }
    private boolean okayCS() {
    	//Util.println("["+myId+"] LM OkCS");
    	//Util.println("["+myId+"] q: "+MyUtil.getArrayString(q));     
    	//Util.println("["+myId+"] v: "+v);
        for (int j = 0; j < N; j++){
            if (isGreater(q[myId], myId, q[j], j))
            {
            	//Util.println("["+myId+"] LM OkCS First Condition Failed");
            	return false;            	
            }
            if (isGreater(q[myId], myId, v.getValue(j), j))
            {
            	//Util.println("["+myId+"] LM OkCS Second Condition Failed");
            	return false;
            }
                
        }
        return true;
    }
    private boolean isGreater(int entry1, int pid1, int entry2, int pid2) {
    	//Util.println("["+myId+"] LM isGreater");        
        if (entry2 == Symbols.Infinity) return false;
        return ((entry1 > entry2) || ((entry1 == entry2) && (pid1 > pid2)));
    }
    public synchronized void handleMsg(Msg m) {
    	Util.println("["+myId+"] LM handleMsg" + m);       
        int timeStamp = m.getMessageInt();
        int src = m.getSrcId();
        String tag = m.getTag();
        v.receiveAction(src, timeStamp);
        
        if (tag.equals("request")) {
            q[src] = timeStamp;
            Q=MyUtil.getArrayString(q);
            sendMsg(src, "ack", ""+v.getValue(myId));
        } else if (tag.equals("release"))
        {
        	q[src] = Symbols.Infinity;
        	Q=MyUtil.getArrayString(q);
        }
        notify(); // okayCS() may be true now
    }
    public String toString(){
    	Util.println("["+myId+"] LM toString");        
    	return "Lamport Mutex: " + myId;
    }
    public void doit(int a){
    	Util.println("["+myId+"] LM doit");        
    	System.out.println("LM["+myId+"]: doit(" + a + " )" );
    }
    public void doit(Double b, int a){
    	Util.println("["+myId+"] LM doit");        
    	System.out.println("LM["+myId+"]: doit(" + b+ " "+ a + " )" );
    }
    public void doit(Integer a, int b, Double c, double d, String e, boolean f, Boolean g){
    	Util.println("["+myId+"] LM doit");        
    	System.out.println("LM["+myId+"]: doit(" + a + " " + b+ " " + c+ " " + d+ " " + e+ " " + f+ " " + g+ " )" );
    }
    
    public void doit(Integer a){
    	Util.println("["+myId+"] LM doit");        
    	System.out.println("LM["+myId+"]: doit(" + a + " )" );
    }
    //Added By Vinit For Simulator
    public Boolean newOkayCS() {
//    for (int j = 0; j < N; j++){
//           if (isGreater(q[myId], myId, q[j], j))
//               return false;
//           if (isGreater(q[myId], myId, v.getValue(j), j))
//               return false;
//       }
        if(q[myId] == Symbols.Infinity) return Boolean.FALSE ;
       for (int i = 0; i < N; i++){
           if (isGreater(q[myId], myId, q[i], i))
               return Boolean.FALSE;
           if (isGreater(q[myId], myId, v.getValue(i), i))
               return Boolean.FALSE;
       }
       System.out.println(" Node : " + myId +" is in CS ...... yipeeee");
       return Boolean.TRUE;
   }
    
}
